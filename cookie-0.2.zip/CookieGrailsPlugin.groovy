class CookieGrailsPlugin {
    // the plugin version
    def version = "0.2"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.1.1 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp"
    ]

    // TODO Fill in these fields
    def author = "Dale Wiggins"
    def authorEmail = "codehaus@sc.dalew.com"
    def title = "Makes dealing with cookies easy"
    def description = '''\\
Provides an injectable service and tag to easily get, set, and delete cookies with one line
'''
	
	def cookieService = new com.studentuniverse.grails.plugins.cookie.services.CookieService()
	
	def observe = ['controllers'] 
	
    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/cookie"

    def doWithSpring = {
        // TODO Implement runtime spring config (optional)
    }

    def doWithApplicationContext = { applicationContext ->
        // TODO Implement post initialization spring config (optional)
    }

    def doWithWebDescriptor = { xml ->
        // TODO Implement additions to web.xml (optional)
    }

    def doWithDynamicMethods = { ctx ->
		extendReqResp()
    }

    def onChange = { event ->
        extendReqResp()
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }
	
	void extendReqResp() {
		javax.servlet.http.HttpServletRequest.metaClass.getCookie = { String name ->
			return cookieService.get(name)
		}
		javax.servlet.http.HttpServletResponse.metaClass.setCookie = { String name, String value, Integer maxAge -> 
			return cookieService.set(delegate,name,value,maxAge)
		}
		javax.servlet.http.HttpServletResponse.metaClass.deleteCookie = { String name -> 
			return cookieService.delete(delegate,name)
		}
	}
}
